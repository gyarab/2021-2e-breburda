package objects.checks;

public enum CheckType {

    SimpleMeleeWeapons,
    SimpleRangedWeapons,
    MartialMeleeWeapons,
    MartialRangedWeapons,
    Spell,
    Armor

}
